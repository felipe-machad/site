import Image from "next/image"
import Link from "next/link"
import { Calendar, MapPin } from "lucide-react"

export function Hero() {
  return (
    <section id="inicio" className="min-h-screen flex items-center justify-center pt-20 pb-16 px-4">
      <div className="max-w-6xl mx-auto w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <div className="inline-block mb-6">
              <span className="text-sm font-medium text-secondary-foreground bg-secondary/50 px-4 py-2 rounded-full">
                ✨ Cuidado personalizado para você
              </span>
            </div>
            
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight mb-6">
              <span className="text-balance">Fisioterapia</span>
              <br />
              <span className="text-primary">Dermatofuncional</span>
            </h1>
            
            <p className="text-lg text-muted-foreground leading-relaxed mb-8 max-w-lg mx-auto lg:mx-0">
              Tratamentos especializados para saúde, bem-estar e estética. 
              Atendimento individual com hora marcada, focado nas suas necessidades.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-10">
              <Link 
                href="https://wa.me/5551999999999" 
                target="_blank"
                className="bg-primary text-primary-foreground px-8 py-4 rounded-full text-base font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
              >
                <Calendar size={20} />
                Agendar Consulta
              </Link>
              <Link 
                href="#servicos"
                className="bg-card text-foreground border border-border px-8 py-4 rounded-full text-base font-medium hover:bg-muted transition-colors flex items-center justify-center"
              >
                Ver Serviços
              </Link>
            </div>

            <div className="flex items-center gap-2 justify-center lg:justify-start text-sm text-muted-foreground">
              <MapPin size={16} className="text-secondary" />
              <span>Flores da Cunha 905, Cachoeirinha Center - Sala 1085</span>
            </div>
          </div>

          <div className="relative">
            <div className="relative w-full aspect-square max-w-md mx-auto">
              <div className="absolute inset-0 bg-primary/20 rounded-full blur-3xl"></div>
              <div className="relative bg-card rounded-3xl p-8 shadow-lg border border-border">
                <Image
                  src="/logo.png"
                  alt="Juliana Alves - Fisioterapeuta Dermatofuncional"
                  width={400}
                  height={400}
                  className="w-full h-auto"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
