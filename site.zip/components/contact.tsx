import { MapPin, Phone, Clock, Instagram, MessageCircle } from "lucide-react"
import Link from "next/link"

export function Contact() {
  return (
    <section id="contato" className="py-20 px-4 bg-card">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-sm font-medium text-secondary-foreground bg-secondary/50 px-4 py-2 rounded-full">
            Contato
          </span>
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mt-6 mb-4">
            Entre em Contato
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Agende sua consulta ou tire suas dúvidas. Estamos prontos para atendê-la!
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Contact Info */}
          <div className="space-y-6">
            <div className="bg-background rounded-2xl border border-border p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center shrink-0">
                  <MapPin size={24} className="text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Endereço</h3>
                  <p className="text-muted-foreground">
                    Flores da Cunha 905<br />
                    Cachoeirinha Center - Sala 1085<br />
                    Cachoeirinha, RS
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-background rounded-2xl border border-border p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center shrink-0">
                  <Phone size={24} className="text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Telefone</h3>
                  <p className="text-muted-foreground">(51) 99999-9999</p>
                  <p className="text-sm text-muted-foreground mt-1">WhatsApp disponível</p>
                </div>
              </div>
            </div>

            <div className="bg-background rounded-2xl border border-border p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center shrink-0">
                  <Clock size={24} className="text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Horário de Atendimento</h3>
                  <p className="text-muted-foreground">
                    Segunda a Sexta: 8h às 19h<br />
                    Sábado: 8h às 13h
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">Atendimento com hora marcada</p>
                </div>
              </div>
            </div>
          </div>

          {/* CTA Card */}
          <div className="bg-primary/5 rounded-2xl border border-primary/20 p-8 flex flex-col justify-center">
            <h3 className="font-serif text-2xl font-bold text-foreground mb-4">
              Agende Sua Consulta
            </h3>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              Entre em contato pelo WhatsApp para agendar sua avaliação e conhecer 
              o tratamento ideal para você. Atendimento personalizado e humanizado.
            </p>

            <div className="space-y-4">
              <Link
                href="https://wa.me/5551999999999"
                target="_blank"
                className="w-full bg-[#25D366] text-white px-6 py-4 rounded-xl font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-3"
              >
                <MessageCircle size={20} />
                Agendar pelo WhatsApp
              </Link>

              <Link
                href="https://instagram.com/jufisioterapia"
                target="_blank"
                className="w-full bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#F77737] text-white px-6 py-4 rounded-xl font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-3"
              >
                <Instagram size={20} />
                Siga no Instagram
              </Link>
            </div>

            <p className="text-xs text-muted-foreground text-center mt-6">
              Resposta em até 24 horas úteis
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
