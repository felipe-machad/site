"use client"

import { useState } from "react"
import { 
  Sparkles, 
  Droplets, 
  Zap, 
  Hand, 
  Syringe, 
  CircleDot,
  Sun,
  Flower2,
  Activity,
  Waves,
  ChevronDown,
  ChevronUp
} from "lucide-react"

const serviceCategories = [
  {
    id: "facial",
    name: "Tratamentos Faciais",
    icon: Sparkles,
    color: "bg-primary/10 text-primary",
    services: [
      {
        name: "Limpeza de Pele",
        description: "Procedimento essencial para remover impurezas, cravos e células mortas, deixando a pele renovada e preparada para absorver melhor os tratamentos.",
        benefits: ["Remoção de cravos e impurezas", "Renovação celular", "Pele mais luminosa", "Prevenção de acne"],
        duration: "60 minutos"
      },
      {
        name: "Peeling de Diamante",
        description: "Esfoliação mecânica que remove as camadas superficiais da pele, estimulando a produção de colágeno e promovendo rejuvenescimento.",
        benefits: ["Redução de manchas", "Suavização de linhas finas", "Textura uniforme", "Estímulo de colágeno"],
        duration: "45 minutos"
      },
      {
        name: "Fotorejuvenescimento",
        description: "Tratamento com luz pulsada que estimula a produção de colágeno e elastina, combatendo os sinais do envelhecimento.",
        benefits: ["Redução de rugas", "Melhora da elasticidade", "Uniformização do tom", "Pele mais firme"],
        duration: "30-45 minutos"
      },
      {
        name: "Microagulhamento",
        description: "Técnica que utiliza microagulhas para estimular a regeneração da pele, tratando cicatrizes, manchas e sinais de envelhecimento.",
        benefits: ["Redução de cicatrizes", "Produção de colágeno", "Tratamento de manchas", "Rejuvenescimento"],
        duration: "60 minutos"
      }
    ]
  },
  {
    id: "corporal",
    name: "Tratamentos Corporais",
    icon: Activity,
    color: "bg-secondary/30 text-secondary-foreground",
    services: [
      {
        name: "Drenagem Linfática",
        description: "Massagem suave que estimula o sistema linfático, eliminando toxinas e reduzindo retenção de líquidos e inchaços.",
        benefits: ["Redução de inchaço", "Eliminação de toxinas", "Melhora da circulação", "Sensação de leveza"],
        duration: "60 minutos"
      },
      {
        name: "Massagem Modeladora",
        description: "Técnica de massagem vigorosa que atua na gordura localizada, modelando o contorno corporal e melhorando a circulação.",
        benefits: ["Modelagem corporal", "Redução de medidas", "Ativação da circulação", "Combate à celulite"],
        duration: "60 minutos"
      },
      {
        name: "Radiofrequência Corporal",
        description: "Tecnologia que aquece as camadas profundas da pele, estimulando colágeno e promovendo firmeza e redução de gordura.",
        benefits: ["Flacidez reduzida", "Produção de colágeno", "Contorno corporal", "Pele mais firme"],
        duration: "45-60 minutos"
      },
      {
        name: "Criolipólise",
        description: "Tratamento não invasivo que congela e elimina células de gordura localizada, remodelando áreas específicas do corpo.",
        benefits: ["Eliminação de gordura", "Não invasivo", "Resultados duradouros", "Contorno definido"],
        duration: "60 minutos por área"
      }
    ]
  },
  {
    id: "relaxamento",
    name: "Massagens e Relaxamento",
    icon: Hand,
    color: "bg-primary/10 text-primary",
    services: [
      {
        name: "Massagem Relaxante",
        description: "Massagem terapêutica com movimentos suaves que promove relaxamento profundo, alívio do estresse e bem-estar geral.",
        benefits: ["Redução do estresse", "Relaxamento muscular", "Melhora do sono", "Bem-estar mental"],
        duration: "60 minutos"
      },
      {
        name: "Massagem com Pedras Quentes",
        description: "Técnica que utiliza pedras aquecidas posicionadas em pontos estratégicos, promovendo relaxamento profundo e alívio de tensões.",
        benefits: ["Alívio de tensões", "Relaxamento profundo", "Melhora circulação", "Equilíbrio energético"],
        duration: "75 minutos"
      },
      {
        name: "Bambuterapia",
        description: "Massagem realizada com bambus de diferentes tamanhos que deslizam pelo corpo, proporcionando drenagem e relaxamento.",
        benefits: ["Drenagem natural", "Relaxamento muscular", "Redução de tensões", "Estímulo circulatório"],
        duration: "60 minutos"
      }
    ]
  },
  {
    id: "estetica-avancada",
    name: "Estética Avançada",
    icon: Zap,
    color: "bg-secondary/30 text-secondary-foreground",
    services: [
      {
        name: "Toxina Botulínica",
        description: "Aplicação de toxina botulínica para suavização de rugas e linhas de expressão, com resultados naturais e duradouros.",
        benefits: ["Suavização de rugas", "Prevenção de linhas", "Aspecto rejuvenescido", "Resultado natural"],
        duration: "30 minutos"
      },
      {
        name: "Preenchimento Facial",
        description: "Procedimento com ácido hialurônico para restaurar volume facial, contornar e harmonizar traços.",
        benefits: ["Restauração de volume", "Harmonização facial", "Hidratação profunda", "Contorno definido"],
        duration: "45 minutos"
      },
      {
        name: "Endermo",
        description: "Tecnologia de sucção e rolamento que trata celulite, melhora a textura da pele e ativa a circulação.",
        benefits: ["Redução de celulite", "Melhora da textura", "Ativação linfática", "Contorno corporal"],
        duration: "45 minutos"
      },
      {
        name: "Corrente Russa",
        description: "Eletroestimulação que promove contração muscular, fortalecendo e tonificando a musculatura.",
        benefits: ["Fortalecimento muscular", "Tonificação", "Definição corporal", "Melhora postural"],
        duration: "30-45 minutos"
      }
    ]
  },
  {
    id: "tratamentos-especiais",
    name: "Tratamentos Especiais",
    icon: Flower2,
    color: "bg-primary/10 text-primary",
    services: [
      {
        name: "Hidrolipoclasia",
        description: "Tratamento que combina injeção de solução salina com ultrassom para quebra de gordura localizada.",
        benefits: ["Redução de gordura", "Procedimento seguro", "Resultados visíveis", "Não cirúrgico"],
        duration: "45-60 minutos"
      },
      {
        name: "Carboxiterapia",
        description: "Aplicação de gás carbônico que melhora a circulação, oxigenação dos tecidos e combate celulite e gordura localizada.",
        benefits: ["Melhora circulação", "Combate celulite", "Oxigenação tecidual", "Firmeza da pele"],
        duration: "30-45 minutos"
      },
      {
        name: "Microblading",
        description: "Técnica de micropigmentação para design e preenchimento de sobrancelhas com aspecto natural fio a fio.",
        benefits: ["Sobrancelhas definidas", "Aspecto natural", "Longa duração", "Realce do olhar"],
        duration: "2 horas"
      },
      {
        name: "Pós-Operatório",
        description: "Tratamentos especializados para recuperação após cirurgias plásticas, acelerando a cicatrização e reduzindo edemas.",
        benefits: ["Recuperação acelerada", "Redução de edemas", "Prevenção de fibroses", "Melhor cicatrização"],
        duration: "60 minutos"
      }
    ]
  }
]

export function Services() {
  const [expandedCategory, setExpandedCategory] = useState<string | null>("facial")
  const [expandedService, setExpandedService] = useState<string | null>(null)

  return (
    <section id="servicos" className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-sm font-medium text-secondary-foreground bg-secondary/50 px-4 py-2 rounded-full">
            Nossos Serviços
          </span>
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mt-6 mb-4">
            Catálogo Completo de Tratamentos
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Conheça todos os nossos serviços especializados em fisioterapia dermatofuncional, 
            desenvolvidos para cuidar da sua saúde, beleza e bem-estar.
          </p>
        </div>

        <div className="space-y-4">
          {serviceCategories.map((category) => (
            <div 
              key={category.id}
              className="bg-card rounded-2xl border border-border overflow-hidden"
            >
              {/* Category Header */}
              <button
                onClick={() => setExpandedCategory(expandedCategory === category.id ? null : category.id)}
                className="w-full px-6 py-5 flex items-center justify-between hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${category.color}`}>
                    <category.icon size={24} />
                  </div>
                  <div className="text-left">
                    <h3 className="font-serif font-semibold text-lg text-foreground">{category.name}</h3>
                    <p className="text-sm text-muted-foreground">{category.services.length} tratamentos disponíveis</p>
                  </div>
                </div>
                {expandedCategory === category.id ? (
                  <ChevronUp size={24} className="text-muted-foreground" />
                ) : (
                  <ChevronDown size={24} className="text-muted-foreground" />
                )}
              </button>

              {/* Category Services */}
              {expandedCategory === category.id && (
                <div className="px-6 pb-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    {category.services.map((service) => (
                      <div 
                        key={service.name}
                        className="bg-background rounded-xl border border-border p-5 hover:border-primary/30 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <h4 className="font-semibold text-foreground">{service.name}</h4>
                          <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full whitespace-nowrap">
                            {service.duration}
                          </span>
                        </div>
                        
                        <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                          {service.description}
                        </p>

                        <button
                          onClick={() => setExpandedService(expandedService === service.name ? null : service.name)}
                          className="text-sm text-primary hover:underline flex items-center gap-1"
                        >
                          {expandedService === service.name ? "Ver menos" : "Ver benefícios"}
                          {expandedService === service.name ? (
                            <ChevronUp size={14} />
                          ) : (
                            <ChevronDown size={14} />
                          )}
                        </button>

                        {expandedService === service.name && (
                          <div className="mt-4 pt-4 border-t border-border">
                            <p className="text-xs font-medium text-foreground mb-2">Benefícios:</p>
                            <ul className="grid grid-cols-2 gap-2">
                              {service.benefits.map((benefit) => (
                                <li key={benefit} className="text-xs text-muted-foreground flex items-center gap-2">
                                  <span className="w-1.5 h-1.5 bg-primary rounded-full"></span>
                                  {benefit}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
