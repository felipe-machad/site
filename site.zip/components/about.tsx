import { Award, Heart, Users, Clock } from "lucide-react"

const features = [
  {
    icon: Award,
    title: "Profissional Qualificada",
    description: "Formação especializada em fisioterapia dermatofuncional com atualizações constantes"
  },
  {
    icon: Heart,
    title: "Cuidado Personalizado",
    description: "Cada paciente recebe um protocolo de tratamento único, adaptado às suas necessidades"
  },
  {
    icon: Users,
    title: "Atendimento Individual",
    description: "Sessões exclusivas para garantir total atenção e privacidade durante o tratamento"
  },
  {
    icon: Clock,
    title: "Horários Flexíveis",
    description: "Agendamento facilitado para se adequar à sua rotina"
  }
]

export function About() {
  return (
    <section id="sobre" className="py-20 px-4 bg-card">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-sm font-medium text-secondary-foreground bg-secondary/50 px-4 py-2 rounded-full">
            Sobre o Consultório
          </span>
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mt-6 mb-4">
            Cuidado e Excelência em Cada Tratamento
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            No consultório de fisioterapia dermatofuncional da Juliana Alves, você encontra 
            tratamentos especializados para saúde, bem-estar e estética, com atendimento 
            humanizado e resultados comprovados.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature) => (
            <div 
              key={feature.title}
              className="bg-background rounded-2xl p-6 border border-border hover:border-primary/50 transition-colors group"
            >
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                <feature.icon size={24} className="text-primary" />
              </div>
              <h3 className="font-serif font-semibold text-foreground mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
