"use client"

import Image from "next/image"
import Link from "next/link"
import { useState } from "react"
import { Menu, X } from "lucide-react"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-card/95 backdrop-blur-sm border-b border-border">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3">
          <Image
            src="/logo.png"
            alt="Juliana Alves - Fisioterapeuta Dermatofuncional"
            width={50}
            height={50}
            className="rounded-full"
          />
          <div className="hidden sm:block">
            <p className="font-serif text-lg font-semibold text-foreground">Juliana Alves</p>
            <p className="text-xs text-muted-foreground tracking-wide">Fisioterapeuta Dermatofuncional</p>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <Link href="#inicio" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Início
          </Link>
          <Link href="#sobre" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Sobre
          </Link>
          <Link href="#servicos" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Serviços
          </Link>
          <Link href="#contato" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Contato
          </Link>
          <Link 
            href="https://wa.me/5551999999999" 
            target="_blank"
            className="bg-primary text-primary-foreground px-5 py-2 rounded-full text-sm font-medium hover:opacity-90 transition-opacity"
          >
            Agendar Consulta
          </Link>
        </nav>

        {/* Mobile Menu Button */}
        <button 
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="md:hidden p-2 text-foreground"
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <nav className="md:hidden bg-card border-t border-border">
          <div className="px-4 py-4 flex flex-col gap-4">
            <Link 
              href="#inicio" 
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Início
            </Link>
            <Link 
              href="#sobre" 
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Sobre
            </Link>
            <Link 
              href="#servicos" 
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Serviços
            </Link>
            <Link 
              href="#contato" 
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Contato
            </Link>
            <Link 
              href="https://wa.me/5551999999999" 
              target="_blank"
              className="bg-primary text-primary-foreground px-5 py-2 rounded-full text-sm font-medium hover:opacity-90 transition-opacity text-center"
            >
              Agendar Consulta
            </Link>
          </div>
        </nav>
      )}
    </header>
  )
}
